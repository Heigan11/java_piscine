package Classes;

import java.time.LocalDateTime;

public class PrinterWithDateTimeImpl implements Printer {

    private String text;
    LocalDateTime date = LocalDateTime.now();

    public PrinterWithDateTimeImpl(String text) {
        this.text = date + " " + text;
    }

    @Override
    public String getText() {
        return text;
    }
}
