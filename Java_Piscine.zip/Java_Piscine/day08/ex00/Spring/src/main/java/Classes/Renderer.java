package Classes;

public interface Renderer {
    void printMessage();
}
