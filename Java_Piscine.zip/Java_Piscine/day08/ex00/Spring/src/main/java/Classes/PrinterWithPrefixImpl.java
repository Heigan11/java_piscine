package Classes;

public class PrinterWithPrefixImpl implements Printer {

    private String text;

    public PrinterWithPrefixImpl(String text) {
        this.text = "Prefix " + text;
    }

    @Override
    public String getText() {
        return text;
    }
}
