package Classes;

public abstract class RendererErrImpl implements Renderer{
    private Printer message;

    public RendererErrImpl(Printer message) {
        this.message = message;
    }

    public void printMessage(){
        System.err.println(message.getText());
    }
}
