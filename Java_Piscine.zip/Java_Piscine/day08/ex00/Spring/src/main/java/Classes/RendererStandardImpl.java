package Classes;

public class RendererStandardImpl implements Renderer{

    private Printer message;

    public RendererStandardImpl(Printer message) {
        this.message = message;
    }

    public void printMessage(){
        System.out.println(message.getText());
    }

}
