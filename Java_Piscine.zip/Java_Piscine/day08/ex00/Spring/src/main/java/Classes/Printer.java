package Classes;

public interface Printer {
    String getText();
}
