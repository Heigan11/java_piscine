package Classes;

public interface Renderer {
    void printMessage(String text);
}
