package Classes;

public interface Printer {
    void print(String text);
}
