package Classes;

public class PrinterWithPrefixImpl implements Printer {

    public Renderer renderer;
    String prefix = "";
    @Override
    public void print(String text) {
        if (prefix != "")
            text = prefix + " " + text;
        renderer.printMessage(text);
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public PrinterWithPrefixImpl(Renderer renderer) {
        this.renderer = renderer;
    }
}
