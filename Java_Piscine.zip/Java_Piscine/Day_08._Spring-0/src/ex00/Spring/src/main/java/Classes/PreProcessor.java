package Classes;

public interface PreProcessor {
    String changeText(String text);
}
