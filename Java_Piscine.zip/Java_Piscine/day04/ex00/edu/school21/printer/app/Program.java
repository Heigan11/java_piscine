package edu.school21.printer.app;

import edu.school21.printer.logic.Logic;

import java.util.Scanner;

public class Program {

    public static void main(String[] args){
        String path;

        Scanner input = new Scanner(System.in);
        path = input.next();
        Logic newLogic = new Logic();
        newLogic.print_img(path);
    }
}