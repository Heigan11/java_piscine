public class User {
    private int identifier;

    @Override
    public String toString() {
        return "User{" +
                "identifier=" + identifier +
                ", name='" + name + '\'' +
                ", balance=" + balance +
                '}';
    }

    private String name;
    private int balance;

    public User( String name, int balance) {

        this.identifier = 0;
        this.name = name;
        this.balance = balance;
    }

    public User( String name) {
        this.identifier = 0;
        this.name = name;
        this.balance = 0;
    }


    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        if (balance < 0) {
            System.err.println("Balance < 0");
            System.exit(-1);
        }
        this.balance = balance; }
}
