public class Program {
    public static void main(String[] args) {
        User user1 = new User( "Tom", -500);
        User user2 = new User( "Bob");
        System.out.println(user1.getBalance());
        Transaction trans1 = new Transaction(user2, user1, 100);
        System.out.println(trans1);
        Transaction trans2 = new Transaction(user2, user1, -300);
        System.out.println(trans2);
    }
}
