import java.util.UUID;


public class Transaction {
    private UUID identifer;

    @Override
    public String toString() {
        return "Transaction{" +
                "identifer=" + identifer +
                ", recipient=" + recipient +
                ", sender=" + sender +
                ", amount=" + amount +
                ", category=" + category +
                '}';
    }

    private User recipient;
    private User sender;
    enum transfer
    {
        DEBIT,
        CREDIT
    }
    private int amount;
    private transfer category;

    public Transaction(User sender, User recipient, int amount) {
        this.identifer = UUID.randomUUID();
        this.recipient = recipient;
        this.sender = sender;
        this.amount = amount;
        if (amount > 0)
        {
            category = transfer.DEBIT;
        }
        else
        {
            category = transfer.CREDIT;
        }

        int currentSenderBalance = sender.getBalance();
        sender.setBalance(currentSenderBalance + amount);

        int currentRecipientBalance = recipient.getBalance();
        recipient.setBalance(currentRecipientBalance - amount);

    }
}
