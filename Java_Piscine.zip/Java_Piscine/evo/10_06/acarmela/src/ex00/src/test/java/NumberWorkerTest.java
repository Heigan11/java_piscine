import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

class NumberWorkerTest {

    private Object Exception;

    @ParameterizedTest
    @ValueSource(ints = {2, 3, 5, 7})
    void isPrimeForPrimes(int number) throws NumberWorker.IllegalNumberException {
        NumberWorker worker_primes = new NumberWorker();
        assertTrue(worker_primes.isPrime(number));
    }

    @ParameterizedTest
    @ValueSource(ints = {4, 100, 333})
    void isPrimeForNotPrimes(int number) throws NumberWorker.IllegalNumberException {
        NumberWorker worker_not_primes = new NumberWorker();
        assertFalse(worker_not_primes.isPrime(number));
    }

    @ParameterizedTest
    @ValueSource(ints = {-4, 0, 1})
    void isPrimeForIncorrectNumbers(int number) {
        NumberWorker worker_incorrect_numbers = new NumberWorker();
        assertThrows(NumberWorker.IllegalNumberException.class, () -> NumberWorker.isPrime(-1));
    }

    @ParameterizedTest
    @CsvFileSource(resources = "data.csv", numLinesToSkip = 1)
    void digitsSum(int number, int expected) {
        NumberWorker worker_incorrect_Sum = new NumberWorker();
        assertEquals(expected, worker_incorrect_Sum.digitsSum(number));
    }
}