public class Program {
    public static void main(String[] args) throws NumberWorker.IllegalNumberException {

        NumberWorker numberWorker = new NumberWorker();
        boolean res = numberWorker.isPrime(100);
        System.out.println(res);

        int sum = numberWorker.digitsSum(00002);
        System.out.println(sum);

    }
}
