public class NumberWorker {

    public static boolean isPrime(int number) throws IllegalNumberException {
        if (number <= 1)
           throw new IllegalNumberException("IllegalArgument", number);


        int iterator = 2;
        while (iterator <= number) {
            if (iterator == number) {
                return (true);
            } else if (number % iterator == 0) {
                return (false);
            } else {
                if (((iterator - 1) * (iterator - 1)) < number &&
                        iterator * iterator > number)
                    return (true);
            }
            iterator++;
        }
        return false;
    }


    public int digitsSum(int value) {
        int result = 0;
        while(value != 0){
            result += (value % 10);
            value/=10;
        }
        if (result < 0)
            result *= -1;
        return (result);
    }

    public static class IllegalNumberException extends Exception{
        private int number;

        public int getNumber() {
            return number;
        }
        public IllegalNumberException(String message, int num) {
            super(message);
            number = num;
        }
    }
}


