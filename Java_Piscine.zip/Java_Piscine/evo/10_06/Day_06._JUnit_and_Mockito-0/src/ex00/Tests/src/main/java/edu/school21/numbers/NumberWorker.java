package edu.school21.numbers;

public class NumberWorker {

public boolean isPrime(int number) {
    if (number <= 1)
        throw new IllegalNumberException();
    if (number % 2 == 0) {
        return (number == 2);
    }
    int numI = 3;
    while (numI * numI <= number) {
        if (number % numI == 0) {
            return (false);
        }
        if (numI == 46339) {
            return (true);
        }
        numI += 2;
    }
    return (true);
}

public int digitsSum(int number) {
    int res = 0;

    while (number > 0) {
        res += number % 10;
        number /= 10;
    }
    return (res);
}

    public static class IllegalNumberException extends RuntimeException {
        public IllegalNumberException() {}
    }
}
