INSERT INTO PRODUCT(NAME, PRICE) VALUES ('product1', 11),
                                        ('product2', 22),
                                        ('product3', 33),
                                        ('product4', 44);