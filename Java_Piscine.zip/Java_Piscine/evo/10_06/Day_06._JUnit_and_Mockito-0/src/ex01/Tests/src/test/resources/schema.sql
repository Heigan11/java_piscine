CREATE TABLE product (
    identifier integer identity PRIMARY KEY ,
    name varchar(25),
    price int
);