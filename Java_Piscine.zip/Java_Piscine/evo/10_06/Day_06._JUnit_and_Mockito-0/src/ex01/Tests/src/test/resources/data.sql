INSERT INTO PRODUCT(NAME, PRICE) VALUES ('product1', 55),
                                        ('product2', 222),
                                        ('product3', 548),
                                        ('product4', 10000);