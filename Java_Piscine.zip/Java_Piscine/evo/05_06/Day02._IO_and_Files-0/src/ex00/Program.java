import java.io.*;
import java.util.Scanner;

public class Program {
    public static FileHexList fhl;
    
    private static int checkFile(String fileName) {
        String str;

        try {
            str = IO.readFile(fileName, 100);
            if (str.equals(""))
                return (1);
            str = fhl.findFileHexItem(str);
            if (str == "") {
                System.err.println("UNDEFINED");
                return (1);
            } else {
                IO.writeFile(str, "./result.txt");
            }
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return (0);
    }

    public static void main(String[] args) throws IOException {
        Scanner scn = new Scanner(System.in);
        String input;

        String sign = new String(IO.readFile("./signatures.txt", 0));
        if (sign.equals("")) {
            System.out.println("Error reading signatures file");
            System.exit(1);
        }
        fhl = new FileHexList(sign);
        input = scn.nextLine();
        while (!input.equals("42")) {
            if (checkFile(input) == 0) 
                System.out.println("PROCESSED");
            input = scn.nextLine();
        }
        scn.close();
        System.exit(0);
    }
}