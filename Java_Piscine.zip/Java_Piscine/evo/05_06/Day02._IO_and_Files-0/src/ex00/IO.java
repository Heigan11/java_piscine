import java.io.*;

public class IO {
    public static void writeFile(String str, String file) throws IOException {
        try {
            FileOutputStream foStream = new FileOutputStream(file, true);
            int i = -1;
            while (++i < str.length())
                foStream.write(str.charAt(i));
            foStream.write(13);
            foStream.close();
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public static String readFile(String file, int len) throws IOException {
        String result = "";

        try {
            FileInputStream fiStream = new FileInputStream(file);
            if (len == 0)
                len = fiStream.available();
            while (len-- > 0)
                result = result + (char)fiStream.read();
            fiStream.close();
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return (result);
    }
}
