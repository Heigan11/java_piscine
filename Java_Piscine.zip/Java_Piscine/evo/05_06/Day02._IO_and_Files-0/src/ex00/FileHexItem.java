public class FileHexItem {
    private String key;
    private String hex;

    public FileHexItem(String str) {
        if (str.length() == 0)
            return ;
        int i = str.indexOf(',');
        if (i < 0) 
            i = 0;
        this.key = str.substring(0, i);
        if (i > 0)
            i++;
        this.hex = str.substring(i, str.length());
        this.hex = this.hex.trim();
    }

    public String getKey() {
        return (key);
    }
    
    public String getHex() {
        return (hex);
    }
}
