import java.util.ArrayList;

public class FileHexList {
    public ArrayList<FileHexItem> sList = new ArrayList<>(10);

    public FileHexList(String signatures) {
        int i = 0;
        String part = "";

        while (i < signatures.length()) {
            if (signatures.charAt(i) == '\n' && !part.equals("")) {
                FileHexItem fhi = new FileHexItem(part);
                addFileHexItem(fhi);
                part = "";
            } else if (signatures.charAt(i) != '\n') {
                part = part + signatures.charAt(i);
            }
            i++;
        }
        if (!part.equals("")) {
            FileHexItem fhi = new FileHexItem(part);
            addFileHexItem(fhi);
        }
    }

    public FileHexItem getItem(Integer idx) {
        return (sList.get(idx));
    }
    
    public void addFileHexItem(FileHexItem fhi) {
        sList.add(fhi);
    }

    public static String strToHex(String str) {
        String result = "";
        String hexChar;

        for (int i = 0; i < str.length(); ++i) {
            hexChar = Integer.toHexString((int)str.charAt(i));
            if (hexChar.length() < 2)
                hexChar = "0" + hexChar;
            result = result + hexChar + " ";
        }
        return (result);
    }

    public String findFileHexItem(String hex) {
        String subStr;

        hex = strToHex(hex);
        for (FileHexItem fhi : sList) {
            subStr = hex.substring(0, fhi.getHex().length());
            if (fhi.getHex().equals(subStr))
                return (fhi.getKey());
        }
        return ("");
    }

}
