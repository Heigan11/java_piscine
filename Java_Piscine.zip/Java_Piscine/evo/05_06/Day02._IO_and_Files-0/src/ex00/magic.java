import java.io.*;
import java.util.Scanner;

public class magic {
    public static FileHexList fhl;
    
/*     public String toHex(String arg) {
        return String.format("%040x", new BigInteger(1, arg.getBytes(YOUR_CHARSET?)));
    } */

    private static void writeFile(String str, String file) throws IOException {
        try {
            FileOutputStream foStream = new FileOutputStream(file, true);
            int i = -1;
            while (++i < str.length()) {
                foStream.write(str.charAt(i));
            }
            foStream.write(13);
            foStream.close();
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    private static String readFile(String file, int len) throws IOException {
        String result = "";

        try {
            FileInputStream fiStream = new FileInputStream(file);
            if (len == 0) {
                len = fiStream.available();
            }
            byte[] buffer = new byte[len];
            fiStream.read(buffer, 0, len);
            fiStream.close();
            result = new String(buffer);
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return (result);
    }

    private static int checkFile(String fileName) {
        String str;

        try {
            str = readFile(fileName, 0);
            str = fhl.findFileHexItem(str);
            if (str == "") {
                System.err.println("UNDEFINED");
            } else {
                writeFile(str, "./result.txt");
            }
            System.out.println(str);
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return (0);
    }

    public static void main(String[] args) throws IOException {
        Scanner scn = new Scanner(System.in);
        String input;

        String sign = new String(readFile("./signatures.txt", 0));
        fhl = new FileHexList(sign);
        for (int i = 0; i < 10; ++i) {
            System.out.println(fhl.get);
        }
        input = scn.nextLine();
        while (!input.equals("42")) {
            checkFile(input);
            System.out.println("PROCESSED");
            input = scn.nextLine();
        }
        scn.close();
        System.exit(0);
    }
}