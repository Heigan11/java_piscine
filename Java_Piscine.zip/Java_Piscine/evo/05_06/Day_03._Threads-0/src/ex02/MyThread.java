public class MyThread extends Thread {
    private int[] array;
    private int startPos;
    private int endPos;
    private boolean isLast;
    private int currSum = 0;

    private static Long sum = 0L;

    public MyThread(String name, int[] array, int startPos, int endPos, boolean isLast) {
        super(name);
        this.array = array;
        this.startPos = startPos;
        this.endPos = endPos;
        this.isLast = isLast;
    }

    public static Long getSum() {
        return sum;
    }

    @Override
    public void run() {
        synchronized (array) {
            int end = isLast ? array.length - 1 : endPos;
            for (int i = startPos; i <= end; i++) {
                currSum += array[i];
            }
            System.out.println(String.format("%s: from %d to %d sum is %d", getName(), startPos,
                    isLast ? array.length - 1 : endPos, currSum));
            sum += currSum;
        }
    }
}
