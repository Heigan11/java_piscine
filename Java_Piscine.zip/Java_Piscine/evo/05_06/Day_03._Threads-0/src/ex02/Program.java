import java.util.Random;

public class Program {
    private static int arraySize = 0;
    private static int threadsCount = 0;

    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("You must pass only two argument");
            System.exit(-1);
        }

        String[] arg1 = args[0].split("=");
        String[] arg2 = args[1].split("=");
        try {
            if (arg1.length != 2 || !arg1[0].equals("--arraySize") || !arg2[0].equals("--threadsCount")) {
                throw new Exception("");
            }
            arraySize = Integer.parseInt(arg1[1]);
            threadsCount = Integer.parseInt(arg2[1]);
		} catch (Exception ex) {
            System.out.println("Invalid option");
            System.exit(-1);
        }

        int[] array = new int[arraySize];
        Random random = new Random();
        int sum = 0;
        for (int i = 0; i < array.length; i++) {
            array[i] = random.nextInt(1000 - (-1000)) + (-1000);
            sum += array[i];
        }
        System.out.println("Sum: " + sum);

        int n = arraySize / threadsCount;
        int reminder = arraySize - n * threadsCount;
        MyThread[] threads = new MyThread[threadsCount];
        int currPos = 0;
        for (int i = 0; i < threadsCount - 1; i++) {
            threads[i] = new MyThread(String.format("Thread%d", i + 1), array, currPos, currPos + n - 1, false);
            currPos += n;
        }
        threads[threadsCount - 1] = new MyThread(String.format("Thread%d", threadsCount), array, currPos, 0, true);

        for (int i = 0; i < threads.length; i++) {
            try {
                threads[i].start();
                threads[i].join();
            } catch (InterruptedException ex) {
                System.out.println(ex.getMessage());
            }
        }

        System.out.println("Sum by threads: " + MyThread.getSum());
    }
}
