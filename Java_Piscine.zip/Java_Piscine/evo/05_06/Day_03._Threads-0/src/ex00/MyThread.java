public class MyThread extends Thread {
    private String value;
    private int count;

    public MyThread(int count, String value) {
        super();
        this.value = value;
        this.count = count;
    }

    @Override
    public void run() {
        for (int i = 0; i < count; i++) {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(value);
        }
    }
}
