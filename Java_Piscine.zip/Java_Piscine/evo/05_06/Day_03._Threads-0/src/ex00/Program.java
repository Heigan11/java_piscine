public class Program {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("You must pass only one argument");
            System.exit(-1);
        }

        String[] arg = args[0].split("=");
        Integer count = null;
        try {
            if (arg.length != 2 || !arg[0].equals("--count")) {
                throw new Exception("");
            }
            count = Integer.parseInt(arg[1]);
        } catch (Exception ex) {
            System.out.println("Invalid option");
            System.exit(-1);
        }

        try {
            MyThread threadHen = new MyThread(count, "Hen");
            MyThread threadEgg = new MyThread(count, "Egg");
            threadEgg.start();
            threadHen.start();
            threadEgg.join();
            threadHen.join();
        } catch (InterruptedException ex) {
            System.out.println(ex.getMessage());
            System.exit(-1);
        }

        for (int i = 0; i < count; i++) {
            System.out.println("Human");
        }
    }
}
