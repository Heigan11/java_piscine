public class Program {
    private static Integer count = null;

    static class ProducerConsumer {
        int state = 0;
        int egg = 0;
        int hen = 0;

        public void produce() throws InterruptedException {
            while (true) {
                if (egg == count) {
                    break;
                }
                synchronized (this) {
                    while (state == 1)
                        wait();
                    state++;
                    System.out.println("Egg");
                    notify();
                    Thread.sleep(1);
                    egg++;
                }
            }
        }

        public void consume() throws InterruptedException {
            while (true) {
                if (hen == count) {
                    break;
                }
                synchronized (this) {
                    while (state == 0)
                        wait();
                    state--;
                    System.out.println("Hen");
                    notify();
                    Thread.sleep(1);
                    hen++;
                }
            }
        }
    }

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("You must pass only one argument");
            System.exit(-1);
        }

        String[] arg = args[0].split("=");
        try {
            if (arg.length != 2 || !arg[0].equals("--count")) {
                throw new Exception("");
            }
            count = Integer.parseInt(arg[1]);
        } catch (Exception ex) {
            System.out.println("Invalid option");
            System.exit(-1);
        }

        ProducerConsumer pc = new ProducerConsumer();

        int i = 0;
        Runnable task1 = () -> {
            try {
                pc.produce();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        };
        Runnable task2 = () -> {
            try {
                pc.consume();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        };
        Thread th1 = new Thread(task1);
        Thread th2 = new Thread(task2);

        th1.start();
        th2.start();

        try {
            th1.join();
            th2.join();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }
}
