public class Program {

    public static void main(String[] args) {
	    int num = 123456;
	    int res = 0;
		res += num % 10;
		num /= 10;
		res += num % 10;
		num /= 10;
		res += num % 10;
		num /= 10;
		res += num % 10;
		num /= 10;
		res += num % 10;
		num /= 10;
		res += num % 10;
		num /= 10;
        System.out.println(res);
    }
}
