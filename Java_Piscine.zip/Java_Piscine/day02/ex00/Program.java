import java.io.*;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Program {

    public static void main(String[] args) throws IOException {
        String value = "";
        String key = "";
        String path = "";
        String type = "";
        byte [] buf = new byte[8];
        char [] line = new char[1000];
        byte [] buf1 = new byte[1];
        byte [] buf4 = new byte[5];
        int i = 0;
        int counter = 0;

        HashMap<String, String> types = new HashMap<>();
        HashMap<byte [], String> output = new HashMap<>();
        FileOutputStream fileOutputStream = new FileOutputStream("result.txt", true);

        FileInputStream sign = new FileInputStream("signatures.txt");

        while((i = sign.read())!= -1) {
            if (counter < 3)
                value += (char) i;
            if (counter == 5)
                key += (char) i;
            if (counter == 6)
                key += (char) i;
            counter++;
            if ((char) i == '\n' || (char) i == '\0') {
                counter = 0;
                types.put(key, value);
                key = "";
                value = "";
            }
        }

        types.put(key, value);
        i = 0;

        InputStream read = System.in;
        while (true) {
            i = 0;
            path = "";
            buf1[0] = '\0';
            line[i] = '\0';
            while ((char) buf1[0] != '\n') {
                read.read(buf1);
                line[i] = (char) buf1[0];
                if (buf1[0] != '\n')
                    path += (char) buf1[0];
                i++;
            }
            line[i - 1] = '\0';
            if (i == 3 && line[0] == '4' && line[1] == '2' && line[2] == '\0') {
                fileOutputStream.close();
                return;
            }
            i = 1;
            try {
                FileInputStream fileInputStream = new FileInputStream(path);
                fileInputStream.read(buf);
                while (i > 0 && i < 4) {
                    type += (char) buf[i];
                    buf4[i - 1] = buf[i];
                    i++;
                }
                buf4[3] = '\n';
                buf4[4] = '\0';
                if (types.containsValue(type)) {
                    System.out.println("PROCESSED");
                    output.put(buf4, "");
                    fileOutputStream.write(buf4);
                }
                else
                    System.out.println("UNDEFINED");
                type = "";
            }
            catch (IOException ex){
                System.out.println("file not found");
            }
        }
    }
}


// /Users/jraye/Desktop/cub.pdf
// /Users/jraye/Desktop/Hello.png
// /Users/jraye/Desktop/111.wav


