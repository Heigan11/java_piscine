package edu.school21.repositories;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import java.sql.Connection;
import java.sql.*;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

public class EmbeddedDataSourceTest {

    EmbeddedDatabaseBuilder builder = new EmbeddedDatabaseBuilder();

    @BeforeEach
    EmbeddedDatabase init() throws SQLException {
        EmbeddedDatabase db = builder.setType(EmbeddedDatabaseType.HSQL).
                addScript("./schema.sql").addScript("./data.sql").build();
        return (db);
    }

    @Test
    public void test_db() throws SQLException {
        EmbeddedDatabase db = init();
        Connection connection = db.getConnection();
        System.out.println(connection.getSchema());
        assertNotNull(connection);
    }
}
