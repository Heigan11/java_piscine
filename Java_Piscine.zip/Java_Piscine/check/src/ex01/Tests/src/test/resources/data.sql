INSERT INTO Product_table(name, price) VALUES ('Burn', 80);
INSERT INTO Product_table(name, price) VALUES ('Adrenalin', 100);
INSERT INTO Product_table(name, price) VALUES ('RedBull', 130);
INSERT INTO Product_table(name, price) VALUES ('Slurm', 100500);
INSERT INTO Product_table(name, price) VALUES ('Monster', 15);