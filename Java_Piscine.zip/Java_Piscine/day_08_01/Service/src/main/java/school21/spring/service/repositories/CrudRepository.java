package school21.spring.service.repositories;

public class CrudRepository {
}
