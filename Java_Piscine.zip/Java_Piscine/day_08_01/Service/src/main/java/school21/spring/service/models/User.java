package school21.spring.service.models;

public class User {
}
