import java.util.UUID;

public class Transaction {
    private UUID identifier;
    private User recipient;
    private User sender;
    private Category category;
    private Integer amount;

    enum Category
    {
        debits,
        credits
    }

public Transaction () {}

public Transaction(User sender, User recipient, Category category, Integer amount){
        this.recipient = recipient;
        this.sender = sender;
        this.category = category;
        if (this.category == Category.debits && amount > 0)
            this.amount = amount;
        else if (this.category == Category.credits && amount < 0)
            this.amount = amount;
        else
            System.out.println("Wrong transaction");
}

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        if (this.category == Category.debits && amount >= 0)
            this.amount = amount;
        else if (this.category == Category.credits && amount <= 0)
            this.amount = amount;
        else
            System.out.println("Wrong transaction");
    }

    public void setIdentifier(UUID identifier) {
        this.identifier = identifier;
    }

    public String getRecipient() {
        return this.recipient.getName();
    }

    public String getSender() {
        return this.sender.getName();
    }

    public Category getCategory(){
        return this.category;
    }

    public UUID getIdentifier() {
        return identifier;
    }
}
