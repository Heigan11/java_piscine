public interface UsersList {
    public void addUser(User user);
    public User retById(int id) throws Exception;
    public User retByIndex(int index);
    public int numOfUsers();
}
