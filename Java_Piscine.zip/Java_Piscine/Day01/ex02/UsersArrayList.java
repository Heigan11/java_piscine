public class UsersArrayList implements UsersList{
    public User[] user_arr;
    int index;

    public UsersArrayList (){
        this.user_arr = new User[10];
        index = -1;
    }

    public void addUser(User user) {
        this.index++;
        if (this.index >= arraySize(this.user_arr))
            newArrCreate(this.user_arr);
        this.user_arr[index] = user;
    }

    public int numOfUsers() {
        return this.index + 1;
    }

    public User retById(int id) throws UserNotFoundException {
        int i = 0;

        while (i < this.index) {
            if (this.user_arr[i].getId() == id)
                return this.user_arr[i];
            i++;
        }
        throw new UserNotFoundException("No such Id");
    }

    public User retByIndex(int index) {
        return this.user_arr[index];
    }

    public int arraySize(User[] array){
        return array.length;
    }

    public void newArrCreate(User[] old_array){
        int i = 0;
        int size = arraySize(old_array);
        User[] new_array = new User[size + size / 2];
        while (i < size) {
        new_array[i] = old_array[i];
        i++;
        }
        this.user_arr = new_array;
    }
}

class UserNotFoundException extends Exception {
    public UserNotFoundException(String msg){
        super(msg);
    }
}
