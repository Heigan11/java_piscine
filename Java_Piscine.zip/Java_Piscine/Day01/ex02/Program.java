import java.util.UUID;

public class Program {

    public static void main(String[] args) {
        int i = 0;

        User john = new User("John", 1000);

        User mike = new User();
        mike.setName("Mike");
        mike.setBalance(2000);

        System.out.println("UsersArrayList:");
        UsersArrayList user_array = new UsersArrayList();

        user_array.addUser(john);
        user_array.addUser(mike);
        System.out.println("arraySize: " + user_array.arraySize(user_array.user_arr));
        while (i++ < 10)
            user_array.addUser(new User());

        System.out.println("arraySize: " + user_array.arraySize(user_array.user_arr));
        System.out.println("numOfUsers: " + user_array.numOfUsers());
        System.out.println("retByIndex: " + user_array.retByIndex(0).getName());
        try {
            System.out.println("retById: " + user_array.retById(2).getName());
        }
        catch (UserNotFoundException ex){
            System.out.println(ex.getMessage());
        }
        try {
            System.out.println("retById: " + user_array.retById(50).getName());
        }
        catch (UserNotFoundException ex){
            System.out.println(ex.getMessage());
        }
    }
}
