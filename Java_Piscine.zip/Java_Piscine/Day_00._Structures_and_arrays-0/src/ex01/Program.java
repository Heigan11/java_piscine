import java.util.Scanner;

public class Program {

    public static void main(String[] args) {
        int number;
        int i;
        int div;

        i = 1;
        div = 3;
        Scanner input = new Scanner(System.in);
        number = input.nextInt ();
        if (number > 1) {
            if (number == 2) {
                System.out.println("true " + i);
                System.exit(0);
            }
            if (number % 2 == 0){
                System.out.println("false " + i);
                System.exit(0);
            }
            while (div <= (number / 2 + 1))
            {
                if (number % div == 0){
                    System.out.println("false " + i);
                    System.exit(0);
                }
                div += 2;
                i++;
            }
            System.out.println("true " + i--);
            System.exit(0);
        }
        else {
            System.err.println("Illegal Argument");
            System.exit(-1);
        }
    }
}