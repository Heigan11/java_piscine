import java.util.Scanner;

public class Program {

    public static void main(String[] args) {
        int sum = 0;
        int count;
        int num = 0;

        count = 0;
        Scanner input = new Scanner(System.in);

        while (true) {
            num = input.nextInt ();
            if (num == 42)
                break;
            sum = get_sum(num);
            if (is_prime(sum) == 1)
                count++;
        }
        System.out.println("Count of coffee-request – " + count);
    }

    public static int get_sum(int number) {
        int tmp = 0;

        while (number >= 10) {
            tmp += number % 10;
            number /= 10;
        }
        tmp += number % 10;
        return(tmp);
    }

    public static int is_prime(int number) {
        int i;
        int div;

        i = 1;
        div = 3;
        if (number == 2)
            return (1);
        if (number % 2 == 0)
            return (0);
        while (div <= (number / 2 + 1))
        {
            if (number % div == 0)
                return (0);
            div += 2;
            i++;
        }
        return (1);
    }
}